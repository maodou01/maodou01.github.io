<?php require_once('Connections/myweb.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form")) {
  $insertSQL = sprintf("INSERT INTO contact (content, cdate) VALUES (%s, %s)",
                       GetSQLValueString($_POST['liuyan'], "text"),
                       GetSQLValueString($_POST['cdate'], "date"));

  mysql_select_db($database_myweb, $myweb);
  $Result1 = mysql_query($insertSQL, $myweb) or die(mysql_error());

  $insertGoTo = "contact.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_myweb, $myweb);
$query_contact = "SELECT * FROM contact ORDER BY id DESC";
$contact = mysql_query($query_contact, $myweb) or die(mysql_error());
$row_contact = mysql_fetch_assoc($contact);
$totalRows_contact = mysql_num_rows($contact);

//initialize the session
if (!isset($_SESSION)) {
  session_start();
}?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/template.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>艺术在于家居</title>
<link href="SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css" />
<!-- InstanceEndEditable -->
<link rel="stylesheet" type="text/css" href="css/index.css"/>
<!-- InstanceBeginEditable name="head" -->
<script src="SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<!-- InstanceEndEditable -->
</head>

<body style="background-color: #f2f2f2">

<div class="header">
  <div class="wrap">
    <div class="logo"><a href=""></a></div>
    <div class="top"><a href="javascript:document.body.style.behavior='url(#default#homepage)';document.body.setHomePage(location.href);">设为首页</a>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:window.external.addFavorite(location.href,'艺术在于家居');">添加收藏</a></div>
    <ul class="nav">
    	<li><a href="index.php">网站首页</a></li>
        <li><a href="about.php">关于我们</a></li>
        <li>
        	<a href="show.php">案例展示</a>
            <ul class="subnav">
            	<li><a href="show1.php">样板房</a></li>
                <li><a href="show2.php">精装修</a></li>
                <li><a href="show3.php">豪华房</a></li>
            </ul>
        </li>
        <li><a href="news.php">新闻中心</a>
        	<ul class="subnav">
            	<li><a href="news1.php">公司新闻</a></li>
                <li><a href="news2.php">装修新闻</a></li>
                <li><a href="news3.php">装修百科</a></li>
                <li><a href="news4.php">产品曝光</a></li>
            </ul>
        </li>
        <li><a href="contact.php">联系我们</a></li>
    </ul>
  </div>
</div>
<div class="banner1"></div>

<div class="wrap zcontent">
	<div class="left-box">
    	<div class="title"><!-- InstanceBeginEditable name="EditRegion1" -->联系我们<!-- InstanceEndEditable --></div>
      <ul><!-- InstanceBeginEditable name="EditRegion2" -->
        	<li><a href="contact.php">联系我们</a></li>
        <!-- InstanceEndEditable --></ul>
    </div>
    <div class="right-box">
    	<div class="zdh"><a href="">网站首页</a> &gt;&gt; <!-- InstanceBeginEditable name="EditRegion3" -->联系我们<!-- InstanceEndEditable --></div>
    	<!-- InstanceBeginEditable name="EditRegion4" --><div class="m-title">网站留言</div>
        <ul class="contact-list">
        
        	<?php do { ?>
              <li> <?php echo $row_contact['cdate']; ?>发言：<?php echo $row_contact['content']; ?></li>
              <?php } while ($row_contact = mysql_fetch_assoc($contact)); ?>
        </ul>
<div class="m-title">我要留言</div>
        <form method="POST" action="<?php echo $editFormAction; ?>" name="form" class="form-box">
        	<input name="cdate" type="hidden" value="<?php echo date("Y-m-d H:i:s"); ?>" />
       	  <span id="sprytextarea1">
        	<textarea name="liuyan" id="textarea1" cols="45" rows="5"></textarea>
        	<span class="textareaRequiredMsg">需要提供一个值。</span></span>
            <input class="btn" name="submitliuyan" type="submit" value="提交留言" />
            <input type="hidden" name="MM_insert" value="form" />
        </form>
        <script type="text/javascript">
var sprytextarea1 = new Spry.Widget.ValidationTextarea("sprytextarea1");
        </script>
   	  <!-- InstanceEndEditable -->
    </div>
</div>

<div class="footer"><p>本站访问：<?php if(!isset($_SESSION["count"])) $_SESSION["count"]=0;$_SESSION["count"]++;echo $_SESSION["count"]; ?>人</p><p>版权声明：所有图片均受著作权保护，未经许可不得使用、转载、摘编。 </p>版权所有 北京全景视觉网络科技股份有限公司 京ICP备10011865号-1  京公网安备11010502022735号</div>
</body>
<!-- InstanceEnd --></html>
<?php
mysql_free_result($contact);
?>
