<?php require_once('Connections/myweb.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['username'])) {
  $loginUsername=$_POST['username'];
  $password=$_POST['password'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "index.php";
  $MM_redirectLoginFailed = "index.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_myweb, $myweb);
  
  $LoginRS__query=sprintf("SELECT username, password FROM `user` WHERE username=%s AND password=%s",
    GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $myweb) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
	if (PHP_VERSION >= 5.1) {session_regenerate_id(true);} else {session_regenerate_id();}
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>艺术在于家居</title>
<link rel="stylesheet" type="text/css" href="css/index.css"/>
</head>

<body>

<div class="header">
  <div class="wrap">
    <div class="logo"><a href=""></a></div>
    <div class="top"><a href="javascript:document.body.style.behavior='url(#default#homepage)';document.body.setHomePage(location.href);">设为首页</a>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:window.external.addFavorite(location.href,'艺术在于家居');">添加收藏</a></div>
    <ul class="nav">
    	<li><a href="index.php">网站首页</a></li>
        <li><a href="about.php">关于我们</a></li>
        <li>
        	<a href="show.php">案例展示</a>
            <ul class="subnav">
            	<li><a href="show1.php">样板房</a></li>
                <li><a href="show2.php">精装修</a></li>
                <li><a href="show3.php">豪华房</a></li>
            </ul>
        </li>
        <li><a href="news.php">新闻中心</a>
        	<ul class="subnav">
            	<li><a href="news1.php">公司新闻</a></li>
                <li><a href="news2.php">装修新闻</a></li>
                <li><a href="news3.php">装修百科</a></li>
                <li><a href="news4.php">产品曝光</a></li>
            </ul>
        </li>
        <li><a href="contact.php">联系我们</a></li>
    </ul>
  </div>
</div>
<div id="banner" class="banner"></div>
<div class="notice">
  <div class="wrap">
  	<marquee>公告：艺术还是艺术艺术还是艺术艺术还是艺术</marquee>
    <div class="login-box">
    <?php if (isset($_SESSION['MM_Username'])){ ?>
    	<?php echo $_SESSION['MM_Username']; ?>，您好,欢迎访问网站。<a class="btn cancel" href="<?php echo $logoutAction ?>">注销</a>
          <a class="btn" href="newsmanage.php">新闻管理</a>
    	<?php }else{  ?>
    	<form ACTION="<?php echo $loginFormAction; ?>" METHOD="POST" id="form-login">
        	<label>用户名：<input name="username" type="text" /></label>&nbsp;&nbsp;&nbsp;&nbsp;
            <label>密码：<input name="password" type="password" /></label>
            <input class="btn" name="" type="submit" value="登录" />
            <input class="btn" name="" type="button" value="注册" onclick="location.href='register.php'" />
        </form>
    <?php }?>
    </div>
  </div>
</div>
<div class="index-title">装修案例</div>
<div class="index-h2">追求天和一境界</div>
<div class="index-p">追求天和一境界追求天和一境界追求天和一境界追求天，和一境界追求天和一境,界追求天和一境界追求天和一境界追求天和一境界追求天和一境界追求天和一境界追求天和一境界追,求天和一境界追求,天<br />一境界追求，天和一境界追求天和一境界追求天和一境界追求,天和一境界追求天和一境界追求<br />天和一境界求天和一境界追求天和一境界追求天和一境界追求天和一境界追求天和一境界追。<br />求天和一境界</div>
<div class="index-pic">
	<div class="wrap" style="text-align: center;">
    	<div class="col-pic">
        	<img src="images/pic01.jpg" />
            <p><a href="#">家居1</a></p>
      	</div>
        <div class="col-pic">
        	<img src="images/pic02.jpg" />
            <p><a href="#">家居2</a></p>
      	</div>
        <div class="col-pic">
        	<img src="images/pic03.jpg" />
            <p><a href="#">家居3</a></p>
      	</div>
    </div>
</div>
<div class="index-title">装修资讯</div>
<div class="index-4box">
	<div class="wrap">
    	<div class="left">
        	<ul>
            	<li>
                	<div class="pic" style="background-image:url(images/pic05.jpg);"></div>
                    <div class="txt">
                    	<p class="title"><a href="#" title="2014年中国城市居民居住满意度揭晓">2014年中国城市居民居住满意度揭晓</a></p>
                        <p class="time">2016/10/10</p>
                        <p class="describe">11月29日上午，2014年中国房地产品牌价值研究成果发布会暨第十一届中国房地产品牌发展高峰论坛在广州召开。本次发布会由省发展中心企业研究所主办。</p>
                    </div>
                </li>
                <li>
                	<div class="pic" style="background-image:url(images/pic06.jpg);"></div>
                    <div class="txt">
                    	<p class="title"><a href="#" title="2014年中国城市居民居住满意度揭晓">2014年中国城市居民居住满意度揭晓</a></p>
                        <p class="time">2016/10/10</p>
                        <p class="describe">11月29日上午，2014年中国房地产品牌价值研究成果发布会暨第十一届中国房地产品牌发展高峰论坛在广州召开。本次发布会由省发展中心企业研究所主办。</p>
                    </div>
                </li>
            </ul>
        </div>
        <div class="left">
        	<ul>
            	<li>
                	<div class="pic" style="background-image:url(images/pic07.jpg);"></div>
                    <div class="txt">
                    	<p class="title"><a href="#" title="2014年中国城市居民居住满意度揭晓">2014年中国城市居民居住满意度揭晓</a></p>
                        <p class="time">2016/10/10</p>
                        <p class="describe">11月29日上午，2014年中国房地产品牌价值研究成果发布会暨第十一届中国房地产品牌发展高峰论坛在广州召开。本次发布会由省发展中心企业研究所主办。</p>
                    </div>
                </li>
                <li>
                	<div class="pic" style="background-image:url(images/pic08.jpg);"></div>
                    <div class="txt">
                    	<p class="title"><a href="#" title="2014年中国城市居民居住满意度揭晓">2014年中国城市居民居住满意度揭晓</a></p>
                        <p class="time">2016/10/10</p>
                        <p class="describe">11月29日上午，2014年中国房地产品牌价值研究成果发布会暨第十一届中国房地产品牌发展高峰论坛在广州召开。本次发布会由省发展中心企业研究所主办。</p>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>
<div class="index-title">装修百科</div>
<div class="index-4box">
	<div class="wrap">
    	<div class="left">
        	<ul>
            	<li>
                	<div class="pic" style="background-image:url(images/pic05.jpg);"></div>
                    <div class="txt">
                    	<p class="title"><a href="#" title="2014年中国城市居民居住满意度揭晓">2014年中国城市居民居住满意度揭晓</a></p>
                        <p class="time">2016/10/10</p>
                        <p class="describe">11月29日上午，2014年中国房地产品牌价值研究成果发布会暨第十一届中国房地产品牌发展高峰论坛在广州召开。本次发布会由省发展中心企业研究所主办。</p>
                    </div>
                </li>
                <li>
                	<div class="pic" style="background-image:url(images/pic06.jpg);"></div>
                    <div class="txt">
                    	<p class="title"><a href="#" title="2014年中国城市居民居住满意度揭晓">2014年中国城市居民居住满意度揭晓</a></p>
                        <p class="time">2016/10/10</p>
                        <p class="describe">11月29日上午，2014年中国房地产品牌价值研究成果发布会暨第十一届中国房地产品牌发展高峰论坛在广州召开。本次发布会由省发展中心企业研究所主办。</p>
                    </div>
                </li>
            </ul>
        </div>
        <div class="left">
        	<ul>
            	<li>
                	<div class="pic" style="background-image:url(images/pic07.jpg);"></div>
                    <div class="txt">
                    	<p class="title"><a href="#" title="2014年中国城市居民居住满意度揭晓">2014年中国城市居民居住满意度揭晓</a></p>
                        <p class="time">2016/10/10</p>
                        <p class="describe">11月29日上午，2014年中国房地产品牌价值研究成果发布会暨第十一届中国房地产品牌发展高峰论坛在广州召开。本次发布会由省发展中心企业研究所主办。</p>
                    </div>
                </li>
                <li>
                	<div class="pic" style="background-image:url(images/pic08.jpg);"></div>
                    <div class="txt">
                    	<p class="title"><a href="#" title="2014年中国城市居民居住满意度揭晓">2014年中国城市居民居住满意度揭晓</a></p>
                        <p class="time">2016/10/10</p>
                        <p class="describe">11月29日上午，2014年中国房地产品牌价值研究成果发布会暨第十一届中国房地产品牌发展高峰论坛在广州召开。本次发布会由省发展中心企业研究所主办。</p>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>
<div class="footer">
<p>本站访问：<?php if(!isset($_SESSION["count"])) $_SESSION["count"]=0;$_SESSION["count"]++;echo $_SESSION["count"]; ?>人</p>
<p>版权声明：所有图片均受著作权保护，未经许可不得使用、转载、摘编。 </p>版权所有 北京全景视觉网络科技股份有限公司 京ICP备10011865号-1  京公网安备11010502022735号</div>
<script>
  var i=1;
  banner();
  function banner(){
	  var _banner=document.getElementById('banner');
	  switch(i){
		  case 1:
		  _banner.style.backgroundImage='url(images/banner.jpg)';
		  i++;
		  break;
		  case 2:
		  _banner.style.backgroundImage='url(images/banner1.jpg)';
		  i=1;
		  break;
	  }
	  setTimeout(banner,3000);
  }
</script>
</body>
</html>