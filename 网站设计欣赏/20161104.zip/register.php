<?php require_once('Connections/myweb.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form")) {
  $insertSQL = sprintf("INSERT INTO `user` (username, password) VALUES (%s, %s)",
                       GetSQLValueString($_POST['username'], "text"),
                       GetSQLValueString($_POST['password1'], "text"));

  mysql_select_db($database_myweb, $myweb);
  $Result1 = mysql_query($insertSQL, $myweb) or die(mysql_error());

  $insertGoTo = "index.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

//initialize the session
if (!isset($_SESSION)) {
  session_start();
}?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/template.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>艺术在于家居</title>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationPassword.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationConfirm.css" rel="stylesheet" type="text/css" />
<!-- InstanceEndEditable -->
<link rel="stylesheet" type="text/css" href="css/index.css"/>
<!-- InstanceBeginEditable name="head" -->
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationConfirm.js" type="text/javascript"></script>
<!-- InstanceEndEditable -->
</head>

<body style="background-color: #f2f2f2">

<div class="header">
  <div class="wrap">
    <div class="logo"><a href=""></a></div>
    <div class="top"><a href="javascript:document.body.style.behavior='url(#default#homepage)';document.body.setHomePage(location.href);">设为首页</a>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:window.external.addFavorite(location.href,'艺术在于家居');">添加收藏</a></div>
    <ul class="nav">
    	<li><a href="index.php">网站首页</a></li>
        <li><a href="about.php">关于我们</a></li>
        <li>
        	<a href="show.php">案例展示</a>
            <ul class="subnav">
            	<li><a href="show1.php">样板房</a></li>
                <li><a href="show2.php">精装修</a></li>
                <li><a href="show3.php">豪华房</a></li>
            </ul>
        </li>
        <li><a href="news.php">新闻中心</a>
        	<ul class="subnav">
            	<li><a href="news1.php">公司新闻</a></li>
                <li><a href="news2.php">装修新闻</a></li>
                <li><a href="news3.php">装修百科</a></li>
                <li><a href="news4.php">产品曝光</a></li>
            </ul>
        </li>
        <li><a href="contact.php">联系我们</a></li>
    </ul>
  </div>
</div>
<div class="banner1"></div>

<div class="wrap zcontent">
	<div class="left-box">
    	<div class="title"><!-- InstanceBeginEditable name="EditRegion1" -->注册<!-- InstanceEndEditable --></div>
      <ul>
      <!-- InstanceBeginEditable name="EditRegion2" -->
      <li><a href="register.php">用户注册</a></li>
        <!-- InstanceEndEditable --></ul>
    </div>
    <div class="right-box">
    	<div class="zdh"><a href="">网站首页</a> &gt;&gt; <!-- InstanceBeginEditable name="EditRegion3" -->注册<!-- InstanceEndEditable --></div>
    	<!-- InstanceBeginEditable name="EditRegion4" --><div class="m-title">注册</div>
		<form method="POST" action="<?php echo $editFormAction; ?>" name="form" class="form-box">
		  <label class="input">
          用户名：
		  <span id="sprytextfield1">
          <input type="text" name="username" id="text1" />
          <span class="textfieldRequiredMsg">需要提供一个值。</span></span>
          </label>
          <label class="input">
          密码：
            <span id="sprypassword1">
            <input type="password" name="password1" id="password2" />
          <span class="passwordRequiredMsg">需要输入一个值。</span></span> </label>
          <label class="input">
          确认密码：
          	<span id="spryconfirm1">
          	<input type="password" name="password2" id="password2" />
       	  <span class="confirmRequiredMsg">需要输入一个值。</span><span class="confirmInvalidMsg">这些值不匹配。</span></span> </label>
          <input class="btn" name="submitregister" type="submit" value="完成注册" />
          <input type="hidden" name="MM_insert" value="form" />
        </form>
	    <script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "none");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3");
var sprypassword1 = new Spry.Widget.ValidationPassword("sprypassword1");
var spryconfirm1 = new Spry.Widget.ValidationConfirm("spryconfirm1", "password2");
        </script>
   	  <!-- InstanceEndEditable -->
    </div>
</div>

<div class="footer"><p>本站访问：<?php if(!isset($_SESSION["count"])) $_SESSION["count"]=0;$_SESSION["count"]++;echo $_SESSION["count"]; ?>人</p><p>版权声明：所有图片均受著作权保护，未经许可不得使用、转载、摘编。 </p>版权所有 北京全景视觉网络科技股份有限公司 京ICP备10011865号-1  京公网安备11010502022735号</div>
</body>
<!-- InstanceEnd --></html>