<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/template.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>艺术在于家居</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" type="text/css" href="css/index.css"/>
<!-- InstanceBeginEditable name="head" -->
<!-- InstanceEndEditable -->
</head>

<body style="background-color: #f2f2f2">

<div class="header">
  <div class="wrap">
    <div class="logo"><a href=""></a></div>
    <div class="top"><a href="javascript:document.body.style.behavior='url(#default#homepage)';document.body.setHomePage(location.href);">设为首页</a>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:window.external.addFavorite(location.href,'艺术在于家居');">添加收藏</a></div>
    <ul class="nav">
    	<li><a href="index.php">网站首页</a></li>
        <li><a href="about.php">关于我们</a></li>
        <li>
        	<a href="show.php">案例展示</a>
            <ul class="subnav">
            	<li><a href="show1.php">样板房</a></li>
                <li><a href="show2.php">精装修</a></li>
                <li><a href="show3.php">豪华房</a></li>
            </ul>
        </li>
        <li><a href="news.php">新闻中心</a>
        	<ul class="subnav">
            	<li><a href="news1.php">公司新闻</a></li>
                <li><a href="news2.php">装修新闻</a></li>
                <li><a href="news3.php">装修百科</a></li>
                <li><a href="news4.php">产品曝光</a></li>
            </ul>
        </li>
        <li><a href="contact.php">联系我们</a></li>
    </ul>
  </div>
</div>
<div class="banner1"></div>

<div class="wrap zcontent">
	<div class="left-box">
    	<div class="title"><!-- InstanceBeginEditable name="EditRegion1" -->新闻中心<!-- InstanceEndEditable --></div>
      <ul><!-- InstanceBeginEditable name="EditRegion2" -->
        	<li><a href="news.php">公司新闻</a></li>
            <li><a href="news.php">装修新闻</a></li>
            <li><a href="news.php">装修百科</a></li>
            <li><a href="news.php">产品曝光</a></li>
        <!-- InstanceEndEditable --></ul>
    </div>
    <div class="right-box">
    	<div class="zdh"><a href="">网站首页</a> &gt;&gt; <!-- InstanceBeginEditable name="EditRegion3" -->新闻中心<!-- InstanceEndEditable --></div>
    	<!-- InstanceBeginEditable name="EditRegion4" --><div class="m-title"><span class="n-content">如果想学习制作渐变效果</span></div>
        <div class="f-title">发布日期：2016-10-29 作者：匿名</div>
        <div class="n-content">
        <p>到此我们关于CSS3─Gradient就介绍到这里了，如果想学习制作渐变效果的，大家可以看看W3CPLUS首页的彩色菜单，我采用的就是CSS3 Gradient实现的，当然大家还可以去看看这个DEMO的效果。希望能给大家对学习CSS3有点帮助，如果感兴趣的朋友请观注W3CPLUS,从今天开始我会系统的介绍一些CSS3的应用，希望大家能喜欢，更希望能跟大家一起探讨学习CSS3的相关技术。</p>
        <p>到此我们关于CSS3─Gradient就介绍到这里了，如果想学习制作渐变效果的，大家可以看看W3CPLUS首页的彩色菜单，我采用的就是CSS3 Gradient实现的，当然大家还可以去看看这个DEMO的效果。希望能给大家对学习CSS3有点帮助，如果感兴趣的朋友请观注W3CPLUS,从今天开始我会系统的介绍一些CSS3的应用，希望大家能喜欢，更希望能跟大家一起探讨学习CSS3的相关技术。</p>
        <p>到此我们关于CSS3─Gradient就介绍到这里了，如果想学习制作渐变效果的，大家可以看看W3CPLUS首页的彩色菜单，我采用的就是CSS3 Gradient实现的，当然大家还可以去看看这个DEMO的效果。希望能给大家对学习CSS3有点帮助，如果<a href="">感兴趣</a>的朋友请观注W3CPLUS,从今天开始我会系统的介绍一些CSS3的应用，希望大家能喜欢，更希望能跟大家一起探讨学习CSS3的相关技术。</p>
      <p class="img"><img src="images/pic06.jpg" /></p>
	  </div>
	  <!-- InstanceEndEditable -->
    </div>
</div>

<div class="footer"><p>本站访问：<?php if(!isset($_SESSION["count"])) $_SESSION["count"]=0;$_SESSION["count"]++;echo $_SESSION["count"]; ?>人</p><p>版权声明：所有图片均受著作权保护，未经许可不得使用、转载、摘编。 </p>版权所有 北京全景视觉网络科技股份有限公司 京ICP备10011865号-1  京公网安备11010502022735号</div>
</body>
<!-- InstanceEnd --></html>