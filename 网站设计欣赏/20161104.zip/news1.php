<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/template.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>艺术在于家居</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" type="text/css" href="css/index.css"/>
<!-- InstanceBeginEditable name="head" -->
<!-- InstanceEndEditable -->
</head>

<body style="background-color: #f2f2f2">

<div class="header">
  <div class="wrap">
    <div class="logo"><a href=""></a></div>
    <div class="top"><a href="javascript:document.body.style.behavior='url(#default#homepage)';document.body.setHomePage(location.href);">设为首页</a>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:window.external.addFavorite(location.href,'艺术在于家居');">添加收藏</a></div>
    <ul class="nav">
    	<li><a href="index.php">网站首页</a></li>
        <li><a href="about.php">关于我们</a></li>
        <li>
        	<a href="show.php">案例展示</a>
            <ul class="subnav">
            	<li><a href="show1.php">样板房</a></li>
                <li><a href="show2.php">精装修</a></li>
                <li><a href="show3.php">豪华房</a></li>
            </ul>
        </li>
        <li><a href="news.php">新闻中心</a>
        	<ul class="subnav">
            	<li><a href="news1.php">公司新闻</a></li>
                <li><a href="news2.php">装修新闻</a></li>
                <li><a href="news3.php">装修百科</a></li>
                <li><a href="news4.php">产品曝光</a></li>
            </ul>
        </li>
        <li><a href="contact.php">联系我们</a></li>
    </ul>
  </div>
</div>
<div class="banner1"></div>

<div class="wrap zcontent">
	<div class="left-box">
    	<div class="title"><!-- InstanceBeginEditable name="EditRegion1" -->新闻中心<!-- InstanceEndEditable --></div>
      <ul><!-- InstanceBeginEditable name="EditRegion2" -->
        	<li><a href="news1.php">公司新闻</a></li>
            <li><a href="news2.php">装修新闻</a></li>
            <li><a href="news3.php">装修百科</a></li>
            <li><a href="news4.php">产品曝光</a></li>
        <!-- InstanceEndEditable --></ul>
    </div>
    <div class="right-box">
    	<div class="zdh"><a href="">网站首页</a> &gt;&gt; <!-- InstanceBeginEditable name="EditRegion3" -->新闻中心<!-- InstanceEndEditable --></div>
    	<!-- InstanceBeginEditable name="EditRegion4" --><ul class="news-list">
	<li><a class="left" href="view.php">2014年中国城市居民居住满意度揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓揭晓</a><span class="time">2016-11-23</span></li>    <li><a class="left" href="#">2014年中国城市居民居住满意度揭晓</a><span class="time">2016-11-23</span></li>
    <li><a class="left" href="view.php">2014年中国城市居民居住满意度揭晓</a><span class="time">2016-11-23</span></li>
    <li><a class="left" href="view.php">2014年中国城市居民居住满意度揭晓</a><span class="time">2016-11-23</span></li>
    <li><a class="left" href="view.php">2014年中国城市居民居住满意度揭晓</a><span class="time">2016-11-23</span></li>
    <li><a class="left" href="view.php">2014年中国城市居民居住满意度揭晓</a><span class="time">2016-11-23</span></li>
    <li><a class="left" href="view.php">2014年中国城市居民居住满意度揭晓</a><span class="time">2016-11-23</span></li>
    <li><a class="left" href="view.php">2014年中国城市居民居住满意度揭晓</a><span class="time">2016-11-23</span></li>    
</ul>
<!-- InstanceEndEditable -->
    </div>
</div>

<div class="footer"><p>本站访问：<?php if(!isset($_SESSION["count"])) $_SESSION["count"]=0;$_SESSION["count"]++;echo $_SESSION["count"]; ?>人</p><p>版权声明：所有图片均受著作权保护，未经许可不得使用、转载、摘编。 </p>版权所有 北京全景视觉网络科技股份有限公司 京ICP备10011865号-1  京公网安备11010502022735号</div>
</body>
<!-- InstanceEnd --></html>