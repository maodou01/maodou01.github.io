<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_myweb = "localhost";
$database_myweb = "test";
$username_myweb = "root";
$password_myweb = "root";
$myweb = mysql_pconnect($hostname_myweb, $username_myweb, $password_myweb) or trigger_error(mysql_error(),E_USER_ERROR); 
mysql_query("SET NAMES 'utf8'");
?>